<?php
    class dbConnect {
        function __construct() {
            require_once('config.php');
            $conn = mysql_connect('localhost', 'root', '');
            mysql_select_db('clinic_project', $conn);
            if(!$conn)
            {
                die ("Cannot connect to the database");
            }
            return $conn;
        }
        public function Close(){
            mysql_close();
        }
    }
?>
